from rest_framework import serializers
from .models import CountrySpecific

class CountrySpecificSerializer(serializers.ModelSerializer):
    class Meta:
        model = CountrySpecific
        fields = '__all__'
