from django.shortcuts import render, redirect, get_object_or_404
from django.core.paginator import Paginator
from django.http import HttpResponse
from GIS_Planning_POC import settings
from .models import CountrySpecific
ms_identity_web = settings.MS_IDENTITY_WEB



# def index(request):  
#     return render(request,'country_specific/index.html')


# def index(request):
#    country_data  =  CountrySpecific.objects.first()  # You might want to fetch the specific data you need
#    return render(request, 'country_specific/index.html', {'country_data': country_data})
@ms_identity_web.login_required
def handle_form_submission(request):
   if request.method  ==  'POST':
       first_wave_custom  =  request.POST.get('first_wave_custom')
       first_wave_default  =  request.POST.get('first_wave_default')
       number_districts_custom = request.POST.get('number_districts_custom')
       number_districts_default = request.POST.get('number_districts_default')
       number_provinces_custom = request.POST.get('number_provinces_custom')
       number_provinces_default = request.POST.get('number_provinces_default')
       population_custom = request.POST.get('population_custom')
       population_default = request.POST.get('population_default')
       size_sqkm_custom = request.POST.get('size_sqkm_custom')
       size_sqkm_default = request.POST.get('size_sqkm_default')
       number_health_facilities_custom = request.POST.get('number_health_facilities_custom')
       number_health_facilities_default = request.POST.get('number_health_facilities_default')
       number_health_workers_custom = request.POST.get('number_health_workers_custom')
       number_health_workers_default = request.POST.get('number_health_workers_default')
       # Create a new CountrySpecific object and save it to the database
       new_country_data  =  CountrySpecific(
           FirstWaveCustom = first_wave_custom,
           FirstWaveDefault = first_wave_default,
           NumberDistrictsCustom = number_districts_custom,
           NumberDistrictsDefault = number_districts_default,
           NumberProvincesCustom = number_provinces_custom,
           NumberProvincesDefault = number_provinces_default,
           PopulationCustom = population_custom,
           PopulationDefault = population_default,
           SizeSQKMCustom = size_sqkm_custom,
           SizeSQKMDefault = size_sqkm_default,
           NumberHealthFacilitiesCustom = number_health_facilities_custom,
           NumberHealthFacilitiesDefault = number_health_facilities_default,
           NumberHealthWorkersCustom = number_health_workers_custom,
           NumberHealthWorkersDefault = number_health_workers_default
           # Add other fields as needed
       )
       new_country_data.save()
     
       return redirect('index') 


@ms_identity_web.login_required
def edit_entry(request):
    if request.method == 'POST':
        entry_id = request.POST.get('entry_id')
        # Fetch the existing data based on entry_id
        entry = get_object_or_404(CountrySpecific, pk=entry_id)
        
        # Update the fields with the submitted data
        entry.FirstWaveCustom = request.POST.get('first_wave_custom')
        entry.FirstWaveDefault = request.POST.get('first_wave_default')
 
        entry.NumberDistrictsCustom = request.POST.get('number_districts_custom')
        entry.NumberDistrictsDefault = request.POST.get('number_districts_default')
 
        entry.NumberProvincesCustom = request.POST.get('number_provinces_custom')
        entry.NumberProvincesDefault = request.POST.get('number_provinces_default')
 
        entry.PopulationCustom = request.POST.get('population_custom')
        entry.PopulationDefault = request.POST.get('population_default')
 
        entry.SizeSQKMCustom = request.POST.get('size_sqkm_custom')
        entry.SizeSQKMDefault = request.POST.get('size_sqkm_default')
 
        entry.NumberHealthFacilitiesCustom = request.POST.get('number_health_facilities_custom')
        entry.NumberHealthFacilitiesDefault = request.POST.get('number_health_facilities_default')
 
        entry.NumberHealthWorkersCustom = request.POST.get('number_health_workers_custom')
        entry.NumberHealthWorkersDefault = request.POST.get('number_health_workers_default')
        # Update other fields as needed
 
        # Save the changes
        entry.save()
 
        return redirect('index')

@ms_identity_web.login_required
def delete_item(request, item_id):
   item = get_object_or_404(CountrySpecific, pk=item_id)
   if request.method == 'POST':
       item.delete()
       return redirect('index')  # Redirect to the index page after deletion
   return render(request, 'country_specific/index.html', {'item': item})

@ms_identity_web.login_required
def index(request):
   # Fetch all data
   country_data_list  =  CountrySpecific.objects.all()
   if request.method  ==  'POST':
       return handle_form_submission(request)
   # Pagination settings
   page  =  request.GET.get('page', 1)
   paginator  =  Paginator(country_data_list, 1)  # Show 1 item per page
   country_data  =  paginator.page(page)
   return render(request, 'country_specific/index.html', {'country_data': country_data})

