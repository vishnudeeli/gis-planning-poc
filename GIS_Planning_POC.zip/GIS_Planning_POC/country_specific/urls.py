from django.urls import path,include
from .viewsets import CountrySpecificSerializerListCreateView, CountrySpecificSerializerRetrieveUpdateDestroyView
from .views import index, edit_entry,delete_item

urlpatterns = [
    path('country_specific/', CountrySpecificSerializerListCreateView.as_view(), name='district-list-create'),
    path('country_specific/<int:pk>/', CountrySpecificSerializerRetrieveUpdateDestroyView.as_view(), name='district-retrieve-update-destroy'),
    path('', index, name='index'), 
    # path('delete_all_data/', delete_all_data, name='delete_all_data'),
    path('delete/<int:item_id>/', delete_item, name='delete_item'),
    path('edit_entry/', edit_entry, name='edit_entry'),

]

