from django.contrib import admin
from django.urls import path,include
import country_specific.urls
import GIS_Planning_POC.views as views
from django.conf.urls.static import static
from ms_identity_web.django.msal_views_and_urls import MsalViews
from django.conf import settings

msal_urls = MsalViews(settings.MS_IDENTITY_WEB).url_patterns()
urlpatterns = [
    path('', views.login, name='login'),
    path('admin/', admin.site.urls),
    path('api/', include(country_specific.urls)),
     path(f'{settings.AAD_CONFIG.django.auth_endpoints.prefix}/', include(msal_urls)),
    *static(settings.STATIC_URL, document_root=settings.STATIC_ROOT),
]

