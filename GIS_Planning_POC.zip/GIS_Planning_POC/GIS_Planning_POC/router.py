from country_specific.viewsets import CountrySpecificSerializerListCreateView,CountrySpecificSerializerRetrieveUpdateDestroyView
from rest_framework import routers

router=routers.DefaultRouter()
router.register('country-specific',CountrySpecificSerializerListCreateView)
router.register('country-specific/<int:pk>/',CountrySpecificSerializerRetrieveUpdateDestroyView)