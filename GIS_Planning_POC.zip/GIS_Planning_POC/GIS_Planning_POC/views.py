from django.shortcuts import redirect

def login(request):
    return redirect('auth/sign_in')