from django.db import models

class CountrySpecific(models.Model):

    FirstWaveCustom = models.CharField(max_length=10)
    FirstWaveDefault = models.CharField(max_length=10)
    NumberDistrictsCustom = models.IntegerField()
    NumberDistrictsDefault = models.IntegerField()
    NumberProvincesCustom = models.IntegerField()
    NumberProvincesDefault = models.IntegerField()
    PopulationCustom = models.IntegerField()
    PopulationDefault = models.IntegerField()
    SizeSQKMCustom = models.FloatField()
    SizeSQKMDefault = models.FloatField()
    NumberHealthFacilitiesCustom = models.IntegerField()
    NumberHealthFacilitiesDefault = models.IntegerField()
    NumberHealthWorkersCustom = models.IntegerField()
    NumberHealthWorkersDefault = models.IntegerField()

    def __str__(self):
        return self.name