from django.apps import AppConfig


class CountrySpecificConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'country_specific'
