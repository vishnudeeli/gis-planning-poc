from rest_framework import generics
from .models import CountrySpecific
from .serializers import CountrySpecificSerializer

class CountrySpecificSerializerListCreateView(generics.ListCreateAPIView):
    queryset = CountrySpecific.objects.all()
    serializer_class = CountrySpecificSerializer

class CountrySpecificSerializerRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CountrySpecific.objects.all()
    serializer_class = CountrySpecificSerializer